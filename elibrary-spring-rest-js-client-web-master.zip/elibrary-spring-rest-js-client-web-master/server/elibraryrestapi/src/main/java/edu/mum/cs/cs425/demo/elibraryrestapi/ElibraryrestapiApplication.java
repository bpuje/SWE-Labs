package edu.mum.cs.cs425.demo.elibraryrestapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ElibraryrestapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ElibraryrestapiApplication.class, args);
	}

}
