package edu.mum.cs.cs425.goldendomemarket.gdmarket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GdmarketApplication {

    public static void main(String[] args) {
        SpringApplication.run(GdmarketApplication.class, args);
    }

}
