package Lab09.arrayutils.q5.service;

public interface ArrayFlattenerService {

    public Integer[] flattenArray(Integer[][] a_in); 

}
