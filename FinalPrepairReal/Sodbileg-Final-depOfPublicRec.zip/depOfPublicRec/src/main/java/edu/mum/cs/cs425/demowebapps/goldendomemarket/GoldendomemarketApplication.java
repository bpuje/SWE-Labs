package edu.mum.cs.cs425.demowebapps.goldendomemarket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GoldendomemarketApplication {

	public static void main(String[] args) {
		SpringApplication.run(GoldendomemarketApplication.class, args);
	}

}
